# Vercel deployment settings

Use these project settings:

- Framework Preset: Vite
- Root Directory: leave blank
- Install Command: npm install --no-audit --no-fund
- Build Command: npm run build
- Output Directory: dist

This release intentionally does not include package-lock.json because an earlier lockfile contained private registry URLs that cannot be accessed by Vercel. The included .npmrc forces installation from the public npm registry.

After replacing the repository, redeploy without using the previous build cache.
